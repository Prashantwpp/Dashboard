import './App.css';
import { SignIn } from './pages/Login/SignIn';
import { AllRoutes } from './pages/Routes/AllRoutes';

function App() {
  return (
    <div className="App">
      <AllRoutes />
    </div>
  );
}

export default App;
