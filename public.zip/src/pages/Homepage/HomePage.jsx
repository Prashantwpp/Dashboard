import React from 'react'
import style from './HomePage.module.css'
export const HomePage = () => {
  return (
    <div>
        <h1>HomePage</h1>
    </div>
  )
}
