import React from 'react'
import style from './SignIn.module.css'
import FormControl from '@mui/material/FormControl';
import OutlinedInput from '@mui/material/OutlinedInput';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import { Link, useNavigate} from "react-router-dom";
import { useState } from 'react';


export const SignIn = () => {
    const [email,setEmail] = useState("");
    const [password,setPassword] = useState("");
    const [typeValue,setTypeValue] = useState("password")
    const [credential,setCredential] = useState("rightCred")
    const navigate = useNavigate();

    const handlePassword = (e)=>{
        setPassword(e.target.value)
        console.log(password);
    }

    const handleEmail = (e)=>{
        setEmail(e.target.value)
        console.log(email);
    }

    const handleSubmit = () =>{
        console.log(password,email)
        if(Number(password) === 1234 && email === "wpp@gmail.com"){
            alert("SuccessFull");
            setCredential("rightCred")
            navigate("/");
        }else{
            setCredential("wrongCred")
        }
    }

    const handleCheckBox = (e) =>{
        if(e.target.checked){
            setTypeValue("text")
        }else{
            setTypeValue("password")
        };
    }
  return (
    <div>
        <div className={style.container}>
           
            <div className={style.shadowBoxContainer}>
                <h1><span>Hi</span> ,Welcome Back</h1>
                <div >
                    {/* <label className={style.gray} for="email">User name</label>
                    <Box component="form" noValidate autoComplete="off" className={style.inputcont}>
                        <FormControl sx={{ width: '100%'}}>
                            <OutlinedInput placeholder="Please enter your name" type="text" onChange={handleName}/>
                        </FormControl>
                    </Box> */}
                    <label className={style.gray} htmlFor="email">Email</label>
                    <Box component="form" noValidate autoComplete="off" className={style.inputcont}>
                        <FormControl sx={{ width: '100%'}}>
                            <OutlinedInput placeholder="Please enter your email" onChange={handleEmail}/>
                        </FormControl>
                    </Box>
                    <label className={style.gray} htmlFor="password">Password</label>
                    <Box component="form" noValidate autoComplete="off" className={style.inputcont}>
                        <FormControl sx={{ width: '100%'}}>
                            <OutlinedInput placeholder="Please enter your password" type={typeValue} onChange={handlePassword}/>
                        </FormControl>
                    </Box>
                    <p className={style[credential]}>Invalid username or Password </p>
                    <div className={style.inputcontO}>
                        <input type="checkbox" onChange={handleCheckBox}/>
                        <label style={{marginTop:"13px", marginRight:"5px"}} >Show password</label>
                    </div>
                    <div className={style.checkBoxSubmit}>
                        <Link to="/signup" className={style.addLink}>Create a new account</Link>
                        <Button variant="contained" disableElevation onClick={handleSubmit}>
                            Login
                        </Button>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
  )
}
